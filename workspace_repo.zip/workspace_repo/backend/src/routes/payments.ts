import express, { Request, Response, NextFunction } from 'express';
import { body, param, validationResult } from 'express-validator';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import mongoose, { Types } from 'mongoose';
import Stripe from 'stripe';
import paypal from '@paypal/checkout-server-sdk';
import crypto from 'crypto';
import { User } from '../models';

const router = express.Router();

// Initialize payment gateways
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

const paypalEnvironment = process.env.NODE_ENV === 'production'
  ? new paypal.core.LiveEnvironment(process.env.PAYPAL_CLIENT_ID || '', process.env.PAYPAL_CLIENT_SECRET || '')
  : new paypal.core.SandboxEnvironment(process.env.PAYPAL_CLIENT_ID || '', process.env.PAYPAL_CLIENT_SECRET || '');

const paypalClient = new paypal.core.PayPalHttpClient(paypalEnvironment);

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';

// Rate limiting configurations
const paymentProcessingLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 payment attempts per windowMs
  message: {
    error: 'Too many payment attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    return req.ip + ':' + (req.headers['x-user-id'] || 'anonymous');
  }
});

const paymentReadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // limit each IP to 50 read operations per windowMs
  message: {
    error: 'Too many requests, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

const refundLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // limit each IP to 3 refund attempts per hour
  message: {
    error: 'Too many refund attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Interfaces
interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    role: string;
  };
}

interface PaymentRecord {
  _id?: Types.ObjectId;
  paymentId: string;
  bookingId: Types.ObjectId;
  userId: Types.ObjectId;
  gateway: 'stripe' | 'paypal';
  gatewayTransactionId: string;
  paymentIntentId?: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded' | 'partially-refunded';
  paymentMethod: string;
  billingDetails: {
    name: string;
    email: string;
    address?: {
      line1: string;
      line2?: string;
      city: string;
      state: string;
      country: string;
      postal_code: string;
    };
  };
  fraudScore?: number;
  fraudChecks: {
    ipGeolocation: boolean;
    velocityCheck: boolean;
    cardBinCheck: boolean;
    deviceFingerprint: boolean;
    riskScore: number;
  };
  refunds: {
    refundId: string;
    amount: number;
    reason: string;
    status: string;
    processedAt: Date;
    processedBy: Types.ObjectId;
  }[];
  metadata: {
    userAgent?: string;
    ipAddress: string