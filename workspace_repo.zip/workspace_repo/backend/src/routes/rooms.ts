import express, { Request, Response, NextFunction } from 'express';
import { body, query, param, validationResult } from 'express-validator';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import mongoose, { Types } from 'mongoose';
import { Hotel, User } from '../models';

const router = express.Router();

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';

// Rate limiting configurations
const readOperationsLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 read operations per windowMs
  message: {
    error: 'Too many requests, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

const writeOperationsLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // limit each IP to 20 write operations per windowMs
  message: {
    error: 'Too many room modification attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

const availabilityLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 50, // limit each IP to 50 availability checks per minute
  message: {
    error: 'Too many availability checks, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// File upload configuration
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB per file
    files: 15 // Maximum 15 files
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Interfaces
interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    role: string;
  };
}

interface RoomDocument {
  _id: Types.ObjectId;
  hotel: Types.ObjectId;
  roomNumber: string;
  name: string;
  type: 'standard' | 'deluxe' | 'suite' | 'family' | 'executive' | 'penthouse';
  description: string;
  images: string[];
  capacity: {
    adults: number;
    children: number;
    maxOccupancy: number;
  };
  beds: {
    type: 'single' | 'double' | 'queen' | 'king' | 'sofa';
    count: number;
  }[];
  size: number;
  amenities: string[];
  pricing: {
    basePrice: number;
    currency: string;
    seasonalRates: {
      season: 'low' | 'mid' | 'high' | 'peak';
      startDate: Date;
      endDate: Date;
      multiplier: number;
    }[];
    weekendMultiplier: number;
    holidayMultiplier: number;
    lengthOfStayDiscounts: {
      minNights: number;
      discount: number;
    }[];
  };
  availability: {
    status: 'available' | 'occupied' | 'maintenance' | 'out-of-order';
    maintenanceSchedule: {
      startDate: Date;
      endDate: Date;
      reason: string;
    }[];
    blockedDates: Date[];
  };
  floor: number;
  view: 'city' | 'ocean' | 'garden' | 'mountain' | 'pool' | 'courtyard';
  isActive: boolean;
  metadata: {
    