import express, { Request, Response, NextFunction } from 'express';
import { body, query, param, validationResult } from 'express-validator';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import mongoose, { Types } from 'mongoose';
import Stripe from 'stripe';
import nodemailer from 'nodemailer';
import { Hotel, User } from '../models';

const router = express.Router();

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';

// Email configuration
const emailTransporter = nodemailer.createTransporter({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
});

// Rate limiting configurations
const readOperationsLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 read operations per windowMs
  message: {
    error: 'Too many requests, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

const writeOperationsLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // limit each IP to 10 write operations per windowMs
  message: {
    error: 'Too many booking modification attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

const bookingCreationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // limit each IP to 5 booking creations per hour
  message: {
    error: 'Too many booking attempts, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Interfaces
interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    role: string;
  };
}

interface IBooking {
  _id?: Types.ObjectId;
  bookingNumber: string;
  user: Types.ObjectId;
  hotel: Types.ObjectId;
  room: Types.ObjectId;
  checkInDate: Date;
  checkOutDate: Date;
  numberOfNights: number;
  guests: {
    adults: number;
    children: number;
  };
  status: 'pending' | 'confirmed' | 'checked-in' | 'checked-out' | 'cancelled' | 'no-show';
  pricing: {
    roomRate: number;
    totalNights: number;
    subtotal: number;
    taxes: number;
    fees: number;
    discounts: number;
    totalAmount: number;
    currency: string;
  };
  payment: {
    method: 'credit-card' | 'debit-card' | 'paypal' | 'bank-transfer' | 'cash';
    status: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded' | 'partially-refunded';
    stripePaymentIntentId?: string;
    transactionId?: string;
    paidAmount: number;
    refundedAmount: number;
    paymentDate?: Date;
  };
  primaryGuest: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  specialRequests?: string;
  accessibilityNeeds?: string;
  cancellationPolicy: {
    type: string;
    deadline: Date;
    penalty: number;
  };
  modifications: {
    modifiedAt: Date;
    modifiedBy: Types.ObjectId;
    changes: any;
    reason?: string;
    fee: number