import mongoose, { Schema, Document, Model, Types } from 'mongoose';
import bcrypt from 'bcrypt';

// Interfaces extending Document for Mongoose
interface IUser extends Document {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  dateOfBirth?: Date;
  role: 'guest' | 'staff' | 'manager' | 'admin';
  isActive: boolean;
  isEmailVerified: boolean;
  avatar?: string;
  address?: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    coordinates?: {
      type: 'Point';
      coordinates: [number, number]; // [longitude, latitude]
    };
  };
  preferences: {
    currency: string;
    language: string;
    timezone: string;
    notifications: {
      email: boolean;
      sms: boolean;
      push: boolean;
      bookingUpdates: boolean;
      promotions: boolean;
      newsletter: boolean;
    };
    roomPreferences: {
      roomType?: string;
      floor?: 'low' | 'high' | 'middle';
      smoking: boolean;
      accessible: boolean;
      quietArea: boolean;
    };
  };
  lastLogin?: Date;
  loginAttempts: number;
  lockUntil?: Date;
  passwordResetToken?: string;
  passwordResetExpires?: Date;
  emailVerificationToken?: string;
  emailVerificationExpires?: Date;
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date;
  createdBy?: Types.ObjectId;
  updatedBy?: Types.ObjectId;
  comparePassword(candidatePassword: string): Promise<boolean>;
  isLocked(): boolean;
  incLoginAttempts(): Promise<void>;
}

interface IHotel extends Document {
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    coordinates: {
      type: 'Point';
      coordinates: [number, number]; // [longitude, latitude]
    };
  };
  contact: {
    email: string;
    phone: string;
    alternatePhone?: string;
    website?: string;
  };
  starRating: number;
  images: string[];
  amenities: {
    name: string;
    icon?: string;
    category: 'room' | 'hotel' | 'business' | 'wellness' | 'dining';
    description?: string;
  }[];
  policies: {
    checkIn: string;
    checkOut: string;
    cancellation: string;
    children: string;
    pets: string;
    smoking: string;
    additionalInfo?: string;
  };
  isActive: boolean;
  isVerified: boolean;
  avgRating: number;
  totalReviews: number;
  priceRange: {
    min: number;
    max: number;
    currency: string;
  };
  totalRooms: number;
  availableRooms: number;
  metadata: {
    yearBuilt?: number;
    lastRenovated?: number;
    floors: number;
    elevators: number;
    parkingSpaces?: number;
  };
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date;
  createdBy?: Types.ObjectId;
  updatedBy?: Types.ObjectId;
}

interface IRoom extends Document {
  hotel: Types.ObjectId;
  roomNumber: string;
  name: string;
  type: 'standard' | 'deluxe' | 'suite' | 'family' | 'executive' | 'penthouse';
  description: string;
  images: string[];
  capacity: {
    adults: number;
    children: number;
    maxOccupancy: number;
  };
  beds: {