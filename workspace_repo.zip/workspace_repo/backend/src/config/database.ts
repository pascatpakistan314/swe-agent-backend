import mongoose from 'mongoose';
import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Types and Interfaces
interface DatabaseConfig {
  mongodb: {
    uri: string;
    options: mongoose.ConnectOptions;
  };
  postgresql: {
    url: string;
    options: any;
  };
}

interface ConnectionState {
  mongodb: {
    connected: boolean;
    lastError?: string;
    lastConnected?: Date;
    reconnectAttempts: number;
  };
  postgresql: {
    connected: boolean;
    lastError?: string;
    lastConnected?: Date;
    reconnectAttempts: number;
  };
}

interface HealthCheck {
  mongodb: {
    status: 'healthy' | 'unhealthy' | 'unknown';
    latency?: number;
    error?: string;
  };
  postgresql: {
    status: 'healthy' | 'unhealthy' | 'unknown';
    latency?: number;
    error?: string;
  };
  timestamp: Date;
}

// Environment Detection
const NODE_ENV = process.env.NODE_ENV || 'development';
const isDevelopment = NODE_ENV === 'development';
const isProduction = NODE_ENV === 'production';
const isStaging = NODE_ENV === 'staging';

// MongoDB Configuration
const getMongoDBConfig = (): mongoose.ConnectOptions => {
  const baseOptions: mongoose.ConnectOptions = {
    // Connection pool settings
    maxPoolSize: isProduction ? 20 : isDevelopment ? 5 : 10,
    minPoolSize: isProduction ? 5 : isDevelopment ? 1 : 2,
    maxIdleTimeMS: 30000,
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
    family: 4,
    
    // Retry logic
    retryWrites: true,
    retryReads: true,
    
    // Buffer settings
    bufferMaxEntries: isProduction ? 20 : 10,
    bufferCommands: false,
    
    // Monitoring
    monitorCommands: isDevelopment,
    
    // Authentication
    authSource: 'admin',
    
    // SSL/TLS
    ssl: isProduction,
    
    // Read/Write concerns
    readPreference: isProduction ? 'secondaryPreferred' : 'primary',
    writeConcern: {
      w: isProduction ? 'majority' : 1,
      j: true,
      wtimeout: 10000
    },
    
    // Additional options
    compressors: isProduction ? ['snappy', 'zlib'] : undefined,
    zlibCompressionLevel: 6,
    
    // Heartbeat
    heartbeatFrequencyMS: 10000,
    localThresholdMS: 15
  };

  return baseOptions;
};

// PostgreSQL Configuration
const getPostgreSQLConfig = () => {
  const baseConfig = {
    // Connection pool settings
    pool: {
      max: isProduction ? 20 : isDevelopment ? 5 : 10,
      min: isProduction ? 5 : isDevelopment ? 1 : 2,
      acquire: 60000,
      idle: 10000,
      evict: 1000,
      handleDisconnects: true
    },
    
    // Logging
    logging: isDevelopment ? console.log : false,
    
    // SSL
    ssl: isProduction ? {
      require: true,
      rejectUnauthorized: false
    } : false,
    
    // Retry logic
    retry: {
      max: 3,
      timeout: 5000
    },
    
    // Query timeout
    statement_timeout: 30000,
    query_timeout: 30000,
    
    // Connection timeout
    connection_timeout: 10000,
    idle_in_transaction_session_timeout: 30000
  };

  return baseConfig;
};

// Database URLs