import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models';
import { Types } from 'mongoose';

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'your-super-secret-refresh-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '15m';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

// Extended Request interface for authenticated requests
export interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    role: string;
    email: string;
    firstName: string;
    lastName: string;
  };
}

// JWT Payload interfaces
interface AccessTokenPayload {
  userId: string;
  role: string;
  iat?: number;
  exp?: number;
}

interface RefreshTokenPayload {
  userId: string;
  type: string;
  iat?: number;
  exp?: number;
}

// User role hierarchy for authorization
const ROLE_HIERARCHY: Record<string, number> = {
  guest: 1,
  staff: 2,
  manager: 3,
  admin: 4
};

// Token extraction utility
const extractToken = (req: Request): string | null => {
  // Check Authorization header (Bearer token)
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }

  // Check cookies
  if (req.cookies && req.cookies.accessToken) {
    return req.cookies.accessToken;
  }

  // Check query parameter (for WebSocket connections)
  if (req.query && req.query.token && typeof req.query.token === 'string') {
    return req.query.token;
  }

  return null;
};

// Generate new access and refresh tokens
export const generateTokens = (userId: string, role: string) => {
  const accessToken = jwt.sign(
    { userId, role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );

  const refreshToken = jwt.sign(
    { userId, type: 'refresh' },
    JWT_REFRESH_SECRET,
    { expiresIn: JWT_REFRESH_EXPIRES_IN }
  );

  return { accessToken, refreshToken };
};

// JWT verification middleware
export const authenticateToken = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const token = extractToken(req);

    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Access token required',
        code: 'TOKEN_MISSING'
      });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AccessTokenPayload;

      // Validate token payload
      if (!decoded.userId || !decoded.role) {
        return res.status(401).json({
          success: false,
          error: 'Invalid token payload',
          code: 'INVALID_TOKEN'
        });
      }

      // Fetch user from database to ensure user still exists and is active
      const user = await User.findById(decoded.userId).select('email firstName lastName role isActive isEmailVerified');
      
      if (!user) {
        return res.status(401).json({
          success: false,
          error: 'User not found',
          code: 'USER_NOT_FOUND'
        });
      }

      if (!user.isActive) {
        return res.status(401).json({
          success: false,
          error: 'Account deactivated',
          code: 'ACCOUNT_DEACTIVATED'
        });
      }

      // Attach user info to request
      req.user = {
        userId: decoded.userId,
        role: user.role,
        email: user.email,
        