import { Server as SocketIOServer } from 'socket.io';
import { Server as HTTPServer } from 'http';
import jwt from 'jsonwebtoken';
import { Types } from 'mongoose';
import { User } from '../models';

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';

// Interfaces
interface AuthenticatedSocket {
  id: string;
  userId: string;
  role: string;
  email: string;
  firstName: string;
  lastName: string;
  join: (room: string) => void;
  leave: (room: string) => void;
  emit: (event: string, data: any) => void;
  disconnect: () => void;
}

interface SocketUser {
  userId: string;
  role: string;
  email: string;
  firstName: string;
  lastName: string;
  socketId: string;
  connectedAt: Date;
  lastActivity: Date;
}

interface RoomAvailabilityUpdate {
  roomId: string;
  hotelId: string;
  status: 'available' | 'occupied' | 'maintenance' | 'out-of-order';
  roomNumber: string;
  roomName: string;
  updatedBy: string;
  timestamp: Date;
  metadata?: {
    reason?: string;
    expectedAvailable?: Date;
    maintenanceType?: string;
  };
}

interface BookingStatusUpdate {
  bookingId: string;
  bookingNumber: string;
  userId: string;
  hotelId: string;
  roomId: string;
  oldStatus: string;
  newStatus: 'pending' | 'confirmed' | 'checked-in' | 'checked-out' | 'cancelled' | 'no-show';
  updatedBy: string;
  timestamp: Date;
  checkInDate: Date;
  checkOutDate: Date;
  guestName: string;
  roomNumber: string;
  hotelName: string;
  metadata?: {
    reason?: string;
    refundAmount?: number;
    notes?: string;
  };
}

interface UserNotification {
  userId: string;
  type: 'booking' | 'payment' | 'system' | 'promotion' | 'reminder';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  title: string;
  message: string;
  data?: any;
  actionUrl?: string;
  expiresAt?: Date;
  timestamp: Date;
  id: string;
}

interface SystemAlert {
  type: 'maintenance' | 'emergency' | 'update' | 'announcement';
  title: string;
  message: string;
  priority: 'info' | 'warning' | 'error' | 'success';
  targetRoles?: string[];
  targetHotels?: string[];
  timestamp: Date;
  expiresAt?: Date;
}

interface ConnectionStats {
  totalConnections: number;
  activeUsers: number;
  connectionsByRole: Record<string, number>;
  averageConnectionTime: number;
  lastUpdated: Date;
}

class WebSocketService {
  private io: SocketIOServer;
  private connectedUsers: Map<string, SocketUser> = new Map();
  private userSockets: Map<string, Set<string>> = new Map(); // userId -> Set of socketIds
  private socketToUser: Map<string, string> = new Map(); // socketId -> userId
  private connectionStats: ConnectionStats = {
    totalConnections: 0,
    activeUsers: 0,
    connectionsByRole: {},
    averageConnectionTime: 0,
    lastUpdated: new Date()
  };

  constructor(server: HTTPServer) {
    this.io = new SocketIOServer(server, {
      cors: {
        origin: process.env.FRONTEND_URL || "http://localhost:3000",
        credentials: true
      },
      transports: ['websocket', 'polling'],
      pingTimeout: 60000,
      pingInterval: 25000
    });

    