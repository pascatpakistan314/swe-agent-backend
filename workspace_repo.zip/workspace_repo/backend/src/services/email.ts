import nodemailer, { Transporter, SendMailOptions } from 'nodemailer';
import { Types } from 'mongoose';

// Types and Interfaces
interface EmailConfig {
  service?: string;
  host?: string;
  port?: number;
  secure?: boolean;
  auth: {
    user: string;
    pass: string;
  };
  pool?: boolean;
  maxConnections?: number;
  maxMessages?: number;
}

interface EmailTemplate {
  subject: string;
  html: string;
  text?: string;
}

interface BookingEmailData {
  bookingNumber: string;
  user: {
    firstName: string;
    lastName: string;
    email: string;
    language?: string;
    preferences?: {
      currency?: string;
      timezone?: string;
    };
  };
  hotel: {
    name: string;
    address: {
      street: string;
      city: string;
      state: string;
      country: string;
      postalCode: string;
    };
    contact: {
      email: string;
      phone: string;
    };
    images?: string[];
    starRating: number;
  };
  room?: {
    name: string;
    type: string;
    images?: string[];
    amenities?: string[];
  };
  checkInDate: Date;
  checkOutDate: Date;
  numberOfNights: number;
  guests: {
    adults: number;
    children: number;
  };
  pricing: {
    roomRate: number;
    subtotal: number;
    taxes: number;
    fees: number;
    totalAmount: number;
    currency: string;
  };
  specialRequests?: string;
  status?: string;
  cancelDeadline?: Date;
  paymentDetails?: {
    method: string;
    status: string;
    transactionId?: string;
    paidAmount: number;
  };
}

interface ReminderEmailData extends BookingEmailData {
  reminderType: '24h' | '48h' | '1week';
  checkInInstructions?: string;
}

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
  attachments?: Array<{
    filename: string;
    content: Buffer | string;
    contentType?: string;
  }>;
  priority?: 'high' | 'normal' | 'low';
}

interface SendResult {
  success: boolean;
  messageId?: string;
  error?: string;
  retryCount?: number;
}

// Language translations
const translations = {
  en: {
    bookingConfirmation: 'Booking Confirmation',
    dear: 'Dear',
    thankYou: 'Thank you for your booking!',
    bookingDetails: 'Booking Details',
    bookingNumber: 'Booking Number',
    hotel: 'Hotel',
    room: 'Room',
    checkIn: 'Check-in',
    checkOut: 'Check-out',
    nights: 'Nights',
    guests: 'Guests',
    adults: 'Adults',
    children: 'Children',
    totalAmount: 'Total Amount',
    roomRate: 'Room Rate',
    subtotal: 'Subtotal',
    taxes: 'Taxes & Fees',
    specialRequests: 'Special Requests',
    needHelp: 'Need Help?',
    contactHotel: 'Contact the hotel directly',
    manageBbooking: 'Manage Your Booking',
    viewBooking: 'View Booking',
    reminder: 'Booking Reminder',
    checkingInSoon: 'You will be checking in soon!',
    upcomingStay: 'Your upcoming stay',
    importantInfo: 'Important Information',
    cancellationPolicy: 'Cancellation Policy',
    checkInTime: 'Standard check-in time',
    checkOutTime: 'Standard check-out time',
    paymentConfirmation: 'Payment Confirmation',
    paymentReceived: 'Payment Received',
    transactionId: 