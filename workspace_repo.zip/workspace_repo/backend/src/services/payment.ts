import mongoose, { Types } from 'mongoose';
import Stripe from 'stripe';
import paypal from '@paypal/checkout-server-sdk';
import crypto from 'crypto';
import { Request } from 'express';

// Environment configuration
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || '';
const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID || '';
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET || '';
const WEBHOOK_SECRET_STRIPE = process.env.STRIPE_WEBHOOK_SECRET || '';
const WEBHOOK_SECRET_PAYPAL = process.env.PAYPAL_WEBHOOK_SECRET || '';

// Initialize payment gateways
const stripe = new Stripe(STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

const paypalEnvironment = process.env.NODE_ENV === 'production'
  ? new paypal.core.LiveEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET)
  : new paypal.core.SandboxEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET);

const paypalClient = new paypal.core.PayPalHttpClient(paypalEnvironment);

// Interfaces and Types
interface PaymentGateway {
  name: string;
  createPaymentIntent(params: PaymentIntentParams): Promise<PaymentIntentResult>;
  capturePayment(paymentIntentId: string): Promise<PaymentResult>;
  processRefund(transactionId: string, amount?: number, reason?: string): Promise<RefundResult>;
  verifyWebhook(payload: string, signature: string): Promise<WebhookVerificationResult>;
  getTransactionDetails(transactionId: string): Promise<TransactionDetails>;
}

interface PaymentIntentParams {
  amount: number;
  currency: string;
  paymentMethodId?: string;
  customerId?: string;
  description?: string;
  metadata?: Record<string, string>;
  billingDetails?: BillingDetails;
  automaticPaymentMethods?: boolean;
}

interface PaymentIntentResult {
  success: boolean;
  paymentIntentId?: string;
  clientSecret?: string;
  status?: string;
  error?: string;
  requiresAction?: boolean;
  nextAction?: any;
}

interface PaymentResult {
  success: boolean;
  transactionId?: string;
  status: PaymentStatus;
  amount?: number;
  currency?: string;
  error?: string;
  rawResponse?: any;
}

interface RefundResult {
  success: boolean;
  refundId?: string;
  amount?: number;
  status?: RefundStatus;
  error?: string;
  estimatedArrival?: Date;
}

interface WebhookVerificationResult {
  isValid: boolean;
  eventType?: string;
  eventData?: any;
  error?: string;
}

interface TransactionDetails {
  transactionId: string;
  amount: number;
  currency: string;
  status: PaymentStatus;
  createdAt: Date;
  paymentMethod?: string;
  billingDetails?: BillingDetails;
  metadata?: Record<string, string>;
}

interface BillingDetails {
  name: string;
  email: string;
  phone?: string;
  address?: {
    line1: string;
    line2?: string;
    city: string;
    state: string;
    country: string;
    postal_code: string;
  };
}

interface FraudAnalysisParams {
  amount: number;
  currency: string;
  ipAddress: string;
  userAgent?: string;
  email: string;
  billingAddress?: BillingDetails['address'];
  userId?: string;
  deviceFingerprint?: string;
  paymentMethod?: string;
}

interface FraudAnalysisResult {
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  checks: {
    ipGeolocation: boolean;
    velocityCheck: boolean;
    