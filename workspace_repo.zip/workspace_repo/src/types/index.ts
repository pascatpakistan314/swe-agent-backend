// Base types and utilities
export interface BaseEntity {
  id: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TimestampedEntity {
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date;
}

// Enums
export enum UserRole {
  GUEST = 'guest',
  STAFF = 'staff',
  MANAGER = 'manager',
  ADMIN = 'admin'
}

export enum BookingStatus {
  PENDING = 'pending',
  CONFIRMED = 'confirmed',
  CHECKED_IN = 'checked-in',
  CHECKED_OUT = 'checked-out',
  CANCELLED = 'cancelled',
  NO_SHOW = 'no-show'
}

export enum PaymentStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  REFUNDED = 'refunded',
  PARTIALLY_REFUNDED = 'partially-refunded'
}

export enum PaymentMethod {
  CREDIT_CARD = 'credit-card',
  DEBIT_CARD = 'debit-card',
  PAYPAL = 'paypal',
  BANK_TRANSFER = 'bank-transfer',
  CASH = 'cash'
}

export enum RoomStatus {
  AVAILABLE = 'available',
  OCCUPIED = 'occupied',
  MAINTENANCE = 'maintenance',
  OUT_OF_ORDER = 'out-of-order'
}

export enum ReviewStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected'
}

export enum RoomType {
  STANDARD = 'standard',
  DELUXE = 'deluxe',
  SUITE = 'suite',
  FAMILY = 'family',
  EXECUTIVE = 'executive',
  PENTHOUSE = 'penthouse'
}

export enum PromotionType {
  PERCENTAGE = 'percentage',
  FIXED_AMOUNT = 'fixed-amount',
  FREE_NIGHTS = 'free-nights',
  UPGRADE = 'upgrade'
}

// Address and Contact Information
export interface Address {
  street: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface ContactInfo {
  email: string;
  phone: string;
  alternatePhone?: string;
}

// User Types
export interface User extends BaseEntity {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  dateOfBirth?: Date;
  role: UserRole;
  isActive: boolean;
  isEmailVerified: boolean;
  avatar?: string;
  address?: Address;
  preferences: UserPreferences;
  lastLogin?: Date;
  bookings?: Booking[];
  reviews?: Review[];
  staffProfile?: Staff;
}

export interface UserPreferences {
  currency: string;
  language: string;
  timezone: string;
  notifications: NotificationPreferences;
  roomPreferences: RoomPreferences;
}

export interface NotificationPreferences {
  email: boolean;
  sms: boolean;
  push: boolean;
  bookingUpdates: boolean;
  promotions: boolean;
  newsletter: boolean;
}

export interface RoomPreferences {
  roomType?: RoomType;
  floor?: 'low' | 'high' | 'middle';
  smoking: boolean;
  accessible: boolean;
  quietArea: boolean;
}

// Hotel Types
export interface Hotel extends BaseEntity {
  name: string;
  description: string;
  address: Address;
  contact: ContactInfo;
  starRating: number;
  images: string[];
  amenities: HotelAmenity[];
  policies: HotelPolicies;
  rooms: Room[];
  staff: Staff[];
  reviews: Review[];
  isActive: boolean;
  check