import { configureStore, createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import { TypedUseSelectorHook, useDispatch, useSelector } from 'react-redux';

// Types based on the project structure
interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: 'guest' | 'staff' | 'manager' | 'admin';
  isActive: boolean;
  isEmailVerified: boolean;
  avatar?: string;
  preferences: {
    currency: string;
    language: string;
    timezone: string;
    notifications: {
      email: boolean;
      sms: boolean;
      push: boolean;
      bookingUpdates: boolean;
      promotions: boolean;
      newsletter: boolean;
    };
    roomPreferences: {
      roomType?: string;
      floor?: 'low' | 'high' | 'middle';
      smoking: boolean;
      accessible: boolean;
      quietArea: boolean;
    };
  };
  lastLogin?: Date;
}

interface Hotel {
  id: string;
  name: string;
  description: string;
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
  contact: {
    email: string;
    phone: string;
    alternatePhone?: string;
  };
  starRating: number;
  images: string[];
  amenities: Array<{
    name: string;
    icon?: string;
    category: 'room' | 'hotel' | 'business' | 'wellness' | 'dining';
    description?: string;
  }>;
  policies: {
    checkIn: string;
    checkOut: string;
    cancellation: string;
    children: string;
    pets: string;
    smoking: string;
  };
  isActive: boolean;
  avgRating: number;
  totalReviews: number;
  priceRange: {
    min: number;
    max: number;
    currency: string;
  };
}

interface Room {
  id: string;
  hotelId: string;
  roomNumber: string;
  name: string;
  type: 'standard' | 'deluxe' | 'suite' | 'family' | 'executive' | 'penthouse';
  description: string;
  images: string[];
  capacity: {
    adults: number;
    children: number;
    maxOccupancy: number;
  };
  beds: Array<{
    type: string;
    count: number;
  }>;
  amenities: string[];
  basePrice: number;
  currentPrice: number;
  currency: string;
  status: 'available' | 'occupied' | 'maintenance' | 'out-of-order';
  isAvailable: boolean;
  area: number;
  floor: number;
}

interface Booking {
  id: string;
  userId: string;
  hotelId: string;
  roomId: string;
  checkInDate: string;
  checkOutDate: string;
  guests: {
    adults: number;
    children: number;
  };
  status: 'pending' | 'confirmed' | 'checked-in' | 'checked-out' | 'cancelled' | 'no-show';
  totalAmount: number;
  currency: string;
  specialRequests?: string;
  guestInfo: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  createdAt: string;
  updatedAt: string;
}

interface Payment {
  id: string;
  bookingId: string;
  amount: number;
  currency: string;
  method: 'credit-card' | 'debit-card' | 'paypal' | 'bank-transfer' | 'cash';
  status: 'pending' |