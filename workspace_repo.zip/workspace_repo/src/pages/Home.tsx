import React, { useState, useEffect, useMemo } from 'react';
import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Button,
  TextField,
  Autocomplete,
  IconButton,
  Chip,
  Rating,
  Skeleton,
  useTheme,
  useMediaQuery,
  Paper,
  Divider,
  Avatar,
  Stack,
  Alert,
} from '@mui/material';
import {
  Search as SearchIcon,
  LocationOn as LocationIcon,
  CalendarToday as CalendarIcon,
  People as PeopleIcon,
  ArrowForward as ArrowForwardIcon,
  Star as StarIcon,
  LocalOffer as OfferIcon,
  Hotel as HotelIcon,
  Restaurant as RestaurantIcon,
  Spa as SpaIcon,
  FitnessCenter as FitnessIcon,
  Wifi as WifiIcon,
  Pool as PoolIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { motion, AnimatePresence } from 'framer-motion';
import { addDays, format, isAfter, isBefore } from 'date-fns';
import { useAppSelector, useAppDispatch } from '@/store';
import { Hotel, Room, UserPreferences } from '@/types';

// Validation Schema
const searchSchema = yup.object({
  location: yup.string().required('Please select a destination'),
  checkInDate: yup.date().required('Check-in date is required').min(new Date(), 'Check-in date cannot be in the past'),
  checkOutDate: yup.date().required('Check-out date is required'),
  adults: yup.number().min(1, 'At least 1 adult is required').max(10, 'Maximum 10 adults allowed'),
  children: yup.number().min(0, 'Children cannot be negative').max(8, 'Maximum 8 children allowed'),
}).test('dates-validation', 'Check-out date must be after check-in date', function(values) {
  const { checkInDate, checkOutDate } = values;
  if (checkInDate && checkOutDate) {
    return isAfter(checkOutDate, checkInDate);
  }
  return true;
});

interface SearchFormData {
  location: string;
  checkInDate: Date | null;
  checkOutDate: Date | null;
  adults: number;
  children: number;
}

interface FeaturedHotel extends Hotel {
  discountPercentage?: number;
  originalPrice?: number;
  currentPrice: number;
  isPromoted?: boolean;
}

interface PromotionalBanner {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  backgroundColor: string;
  textColor: string;
  discount?: string;
}

interface CallToActionSection {
  id: string;
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  icon: React.ReactNode;
  color: 'primary' | 'secondary' | 'success' | 'warning';
}

const Home: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const dispatch = use