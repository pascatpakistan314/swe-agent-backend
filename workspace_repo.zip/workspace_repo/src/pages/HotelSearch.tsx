import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Chip,
  Rating,
  Skeleton,
  useTheme,
  useMediaQuery,
  Paper,
  Divider,
  Slider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  FormGroup,
  IconButton,
  Collapse,
  Drawer,
  AppBar,
  Toolbar,
  Badge,
  Stack,
  CircularProgress,
  Alert,
  Tooltip,
  ToggleButton,
  ToggleButtonGroup,
  Avatar,
  CardActions,
} from '@mui/material';
import {
  FilterList as FilterIcon,
  Sort as SortIcon,
  Map as MapIcon,
  List as ListIcon,
  Close as CloseIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  LocationOn as LocationIcon,
  Star as StarIcon,
  Wifi as WifiIcon,
  Pool as PoolIcon,
  Restaurant as RestaurantIcon,
  FitnessCenter as FitnessIcon,
  Spa as SpaIcon,
  LocalParking as ParkingIcon,
  RoomService as RoomServiceIcon,
  AcUnit as AcIcon,
  Business as BusinessIcon,
  Pets as PetsIcon,
  Accessible as AccessibleIcon,
  Favorite as FavoriteIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Share as ShareIcon,
  DirectionsWalk as WalkIcon,
  LocalOffer as OfferIcon,
  TrendingUp as TrendingUpIcon,
  AccessTime as TimeIcon,
} from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useAppSelector, useAppDispatch } from '@/store';
import { Hotel, Room } from '@/types';

// Interfaces
interface SearchFilters {
  priceRange: [number, number];
  starRating: number[];
  amenities: string[];
  guestRating: number;
  distance: number;
  hotelTypes: string[];
  accessibility: boolean;
  petFriendly: boolean;
}

interface SortOption {
  value: string;
  label: string;
  icon: React.ReactNode;
}

interface HotelSearchResult extends Hotel {
  distance: number;
  currentPrice: number;
  originalPrice?: number;
  discountPercentage?: number;
  isSponsored?: boolean;
  lastBookedMinutes?: number;
  roomsLeft?: number;
  isFavorite?: boolean;
}

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  hotel: HotelSearchResult;
  price: number;
}

// Constants
const AMENITY_ICONS: Record<string, React.ReactNode> = {
  wifi: <WifiIcon />,
  pool: <PoolIcon />,
  restaurant: <RestaurantIcon />,
  fitness: <FitnessIcon />,
  spa: <SpaIcon />,
  parking: <ParkingIcon />,
  'room-service': <RoomServiceIcon />,
  'air-conditioning': <AcIcon />,
  'business-center': <BusinessIcon />,
  'pet-friendly': <PetsIcon />,
  accessible: <AccessibleIcon />,
};

const SORT_OPTIONS: SortOption[] = [
  { value: 'relevance', label: 'Best Match', icon: <TrendingUpIcon /> },
  { value: 'price-low', label: 'Price: Low to High', icon: <SortIcon /> },
  { value: 'price-high', label: 'Price: High to Low', icon: <SortIcon />