import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Chip,
  Rating,
  Avatar,
  Divider,
  Tabs,
  Tab,
  Paper,
  Stack,
  IconButton,
  Badge,
  LinearProgress,
  CircularProgress,
  Alert,
  AlertTitle,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Skeleton,
  useTheme,
  useMediaQuery,
  Tooltip,
  Collapse,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Menu,
  MenuList,
  ListItemAvatar,
} from '@mui/material';
import {
  Dashboard as DashboardIcon,
  BookOnline as BookingIcon,
  Person as PersonIcon,
  Star as StarIcon,
  History as HistoryIcon,
  Edit as EditIcon,
  Cancel as CancelIcon,
  Receipt as ReceiptIcon,
  Hotel as HotelIcon,
  CalendarToday as CalendarIcon,
  People as PeopleIcon,
  LocationOn as LocationIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Save as SaveIcon,
  Close as CloseIcon,
  MoreVert as MoreVertIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  LocalOffer as OfferIcon,
  EmojiEvents as TrophyIcon,
  CardGiftcard as GiftIcon,
  Loyalty as LoyaltyIcon,
  Grade as GradeIcon,
  TrendingUp as TrendingUpIcon,
  AccessTime as TimeIcon,
  ExpandMore as ExpandMoreIcon,
  Visibility as ViewIcon,
  Download as DownloadIcon,
  Repeat as RepeatIcon,
  RateReview as ReviewIcon,
  Search as SearchIcon,
  FilterList as FilterIcon,
  Sort as SortIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';
import { format, addDays, differenceInDays, isAfter, isBefore, parseISO } from 'date-fns';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import toast from 'react-hot-toast';
import { useAppSelector, useAppDispatch } from '@/store';

// Interfaces
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

interface BookingCardProps {
  booking: any;
  onCancel: (bookingId: string) => void;
  onViewDetails: (bookingId: string) => void;
  onRepeatBooking: (booking: any) => void;
  onReview: (booking: any) => void;
}

interface LoyaltyProgram {
  currentPoints: number;
  currentTier: string;
  nextTier: string;
  pointsToNextTier: number;
  totalPointsEarned: number;
  rewardsAvailable: Reward[];
  recentActivities: LoyaltyActivity[];
}

interface Reward {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  category: string;
  expiryDate?: string;
  image?: string;
}

interface LoyaltyActivity {
  id: string;
  type: '