import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Chip,
  Rating,
  Skeleton,
  useTheme,
  useMediaQuery,
  Paper,
  Divider,
  Avatar,
  Stack,
  CircularProgress,
  Alert,
  Tooltip,
  Fab,
  Badge,
  IconButton,
  Collapse,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  AppBar,
  Toolbar,
  Slide,
  Tab,
  Tabs,
  TabPanel,
  LinearProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Favorite as FavoriteIcon,
  FavoriteBorder as FavoriteBorderIcon,
  Share as ShareIcon,
  LocationOn as LocationIcon,
  Star as StarIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Close as CloseIcon,
  Fullscreen as FullscreenIcon,
  Wifi as WifiIcon,
  Pool as PoolIcon,
  Restaurant as RestaurantIcon,
  FitnessCenter as FitnessIcon,
  Spa as SpaIcon,
  LocalParking as ParkingIcon,
  RoomService as RoomServiceIcon,
  AcUnit as AcIcon,
  Business as BusinessIcon,
  Pets as PetsIcon,
  Accessible as AccessibleIcon,
  ExpandMore as ExpandMoreIcon,
  CalendarToday as CalendarIcon,
  People as PeopleIcon,
  Bed as BedIcon,
  Bathtub as BathroomIcon,
  SquareFoot as AreaIcon,
  CheckCircle as CheckIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Language as WebsiteIcon,
  Map as MapIcon,
  DirectionsWalk as WalkIcon,
  LocalOffer as OfferIcon,
  AccessTime as TimeIcon,
  TrendingUp as TrendingUpIcon,
  FilterList as FilterIcon,
  Sort as SortIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { format, addDays, differenceInDays, isAfter, isBefore, startOfDay } from 'date-fns';
import { useAppSelector, useAppDispatch } from '@/store';
import { Hotel, Room, UserRole } from '@/types';

// Interfaces
interface HotelDetailsProps {}

interface RoomAvailability {
  date: string;
  available: boolean;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
}

interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  title: string;
  comment: string;
  date: string;
  helpful: number;
  roomType: string;
  stayDuration: number;
  verified: boolean;
  photos?: string[];
  response?: {
    text: string;
    date: string;
    responderName: string;
  };