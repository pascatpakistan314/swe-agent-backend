import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  Box,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  useTheme,
  useMediaQuery,
  Chip,
} from '@mui/material';
import {
  Menu as MenuIcon,
  AccountCircle,
  NotificationsOutlined,
  DashboardOutlined,
  BookOnlineOutlined,
  RoomOutlined,
  PeopleOutlined,
  AssessmentOutlined,
  SettingsOutlined,
  HotelOutlined,
  PersonOutlined,
  InfoOutlined,
  ContactMailOutlined,
  HomeOutlined,
  ExitToAppOutlined,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAppSelector, useAppDispatch } from '@/store';
import { UserRole, BookingStatus } from '@/types';

interface HeaderProps {
  showLogo?: boolean;
  logoText?: string;
  className?: string;
}

interface NavigationItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  roles: UserRole[];
}

const navigationItems: NavigationItem[] = [
  {
    label: 'Home',
    path: '/',
    icon: <HomeOutlined />,
    roles: [UserRole.GUEST, UserRole.STAFF, UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Rooms',
    path: '/rooms',
    icon: <RoomOutlined />,
    roles: [UserRole.GUEST, UserRole.STAFF, UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'About',
    path: '/about',
    icon: <InfoOutlined />,
    roles: [UserRole.GUEST],
  },
  {
    label: 'Contact',
    path: '/contact',
    icon: <ContactMailOutlined />,
    roles: [UserRole.GUEST],
  },
  {
    label: 'Dashboard',
    path: '/dashboard',
    icon: <DashboardOutlined />,
    roles: [UserRole.STAFF, UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Bookings',
    path: '/bookings',
    icon: <BookOnlineOutlined />,
    roles: [UserRole.STAFF, UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Guests',
    path: '/guests',
    icon: <PersonOutlined />,
    roles: [UserRole.STAFF, UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Staff',
    path: '/staff',
    icon: <PeopleOutlined />,
    roles: [UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Reports',
    path: '/reports',
    icon: <AssessmentOutlined />,
    roles: [UserRole.MANAGER, UserRole.ADMIN],
  },
  {
    label: 'Hotels',
    path: '/hotels',
    icon: <HotelOutlined />,
    roles: [UserRole.ADMIN],
  },
  {
    label: 'Users',
    path: '/users',
    icon: <PeopleOutlined />,
    roles: [UserRole.ADMIN],
  },
  {
    label: 'Analytics',
    path: '/analytics',
    icon: <AssessmentOutlined />,
    roles: [UserRole.ADMIN],
  },
  {
    label: 'Settings',
    path: '/settings',
    icon: <SettingsOutlined />,
    roles: [UserRole.ADMIN],
  },
];

const Header: React.FC<HeaderProps